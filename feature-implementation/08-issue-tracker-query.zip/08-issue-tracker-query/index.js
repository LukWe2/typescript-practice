import { searchIssues, filterIssues, sortIssues, paginate, queryIssues } from "./issueService.js";
import { issues } from "./data.js";
function main() {
    const issuesWithMobileInTitle = searchIssues(issues, "mobile");
    console.log("Issues with mobile in title: ", issuesWithMobileInTitle);
    const issuesOpenHighPriority = filterIssues(issues, { status: "open", priority: "high" });
    console.log("Open High Priority Issues: ", issuesOpenHighPriority);
    const issuesAllAssigned = filterIssues(issues, { assignedOnly: true });
    console.log("All assigned issues: ", issuesAllAssigned);
    const issuesSortedByTitleAscending = sortIssues(issues, "title", "asc");
    console.log("Issues sorted by title ascending: ", issuesSortedByTitleAscending);
    const issuesSortedByIdDescending = sortIssues(issues, "id", "desc");
    console.log("Issues sorted by ID descending: ", issuesSortedByIdDescending);
    const paginatedIssuesFromPage2With2ElementsPerPage = paginate(issues, 2, 2);
    console.log("Paginated issues from page 2 with 2 elements per page: ", paginatedIssuesFromPage2With2ElementsPerPage);
    const combinedQuery = queryIssues(issues, { searchTerm: "p", filter: { assignedOnly: true }, sortBy: "id", page: 3, pageSize: 2 });
    console.log("Combined Query with search, filter, sort and pagination: ", combinedQuery);
    console.log("Query current page: ", combinedQuery.page);
    console.log("Query page size/elements per page: ", combinedQuery.pageSize);
    console.log("Query amount of results: ", combinedQuery.items.length);
    console.log("Query amount of pages: ", combinedQuery.totalPages);
    console.log("Query items of current page: ", combinedQuery.items);
}
;
main();
//# sourceMappingURL=index.js.map